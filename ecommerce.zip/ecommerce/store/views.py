from django.shortcuts import render, HttpResponse,redirect
from django.http import JsonResponse
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout

import json
import datetime
from .models import *
from .utils import cookieCart,cartData, guestOrder

def store(request):
    data = cartData(request)
    cartItems = data['cartItems']
    products = Product.objects.all()
    context = {'products': products, 'cartItems': cartItems, 'shipping':False}
    return render(request, 'store/store.html', context)


def cart(request):
    data = cartData(request)
    cartItems = data['cartItems']
    order = data['order']
    items = data['items']
    context = {'items':items, 'order':order,  'cartItems': cartItems, 'shipping':False}
    return render(request, 'store/cart.html', context)

def checkout(request):
    data = cartData(request)
    cartItems = data['cartItems']
    order = data['order']
    items = data['items']
    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'store/checkout.html', context)

def updateItem(request):
    data = json.loads(request.body)
    productId = data['productId']
    action = data['action']

    print('Action: ',action)
    print('productId: ',productId)

    customer = request.user.customer
    product = Product.objects.get(id=productId)
    order, created = Order.objects.get_or_create(customer=customer, complete=False)
    orderItem, created = OrderItem.objects.get_or_create(order = order, product=product)
    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)
    orderItem.save()
    if orderItem.quantity <= 0:
        orderItem.delete()
    return JsonResponse('Item was added', safe=False)

#from django.views.decorators.csrf import csrf_exempt
#@csrf_exempt
def processOrder(request):
    transaction_id = datetime.datetime.now().timestamp()
    data = json.loads(request.body)
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)


    else:
        customer, order = guestOrder(request, data)
    total = float(data['form']['total'])
    order.transaction_id = transaction_id

    if total == order.get_cart_total:
        order.complete = True
    order.save()

    if order.shipping == True:
        ShippingAddress.objects.create(
            customer=customer,
            order=order,
            address=data['shipping']['address'],
            city=data['shipping']['city'],
            state=data['shipping']['state'],
            zipcode=data['shipping']['zipcode'],
            country=data['shipping']['country'],

        )
    return JsonResponse('Payment Complete!', safe=False)

def search(request):
    """if request.method == "POST":
        searched = request.POST['searched'],
        return render(request, 'store/search.html',{'searched:':searched})
    else:
        return render(request, 'store/search.html',{})"""
    data = cartData(request)
    cartItems = data['cartItems']
    query = request.GET['search']
    allPosts = Product.objects.filter(name__icontains=query)
    params = {'allPosts':allPosts, 'cartItems': cartItems}
    return  render(request,'store/search.html', params)
    #return  HttpResponse('This is search')

def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        #checks
        if len(username) > 15:
            messages.warning(request,"Username must be under 15 characters!!")
            return redirect('/')
        if not username.isalnum():
            messages.warning(request,"Username must contain only numbers and letters!!")
            return redirect('/')
        if pass1 != pass2:
            messages.warning(request, "Passwords do not match!!")
            return redirect('/')
        #create user
        myuser= User.objects.create_user(username, email, pass1)
        myuser.first_name= fname
        myuser.last_name= lname
        myuser.save()
        messages.success(request, "Your account has been created successfully!")
        return redirect('/')

    else:
        return HttpResponse('404 - Not Found!')

def handleLogin(request):
    if request.method == 'POST':
        loginUsername = request.POST['loginUsername']
        loginPass = request.POST['loginPass']

        user = authenticate(username = loginUsername, password = loginPass)
        if user is not None:
            login(request, user)
            messages.add_message(request, messages.INFO,"Successfully Logged in!")
            return redirect('/')
        else:
            messages.error(request, "Invalid credentials, Please try again!")
            return redirect('/')

    return HttpResponse('404 - Not Found!')

def handleLogout(request):
    logout(request)
    messages.success(request, "Successfully Logged out!")
    return redirect('/')
        #return HttpResponse('logout')

def prodView(request,nm):
    return render(request, 'store/'+nm+'Product.html')
