from django.urls import path

from . import views

urlpatterns = [
	#Leave as empty string for base url
	path('', views.store, name="store"),
	path('cart/', views.cart, name="cart"),
	path('checkout/', views.checkout, name="checkout"),
	path('update_item/', views.updateItem, name="update_item"),
	path('process_order/', views.processOrder, name="process_order"),
	path('search/', views.search, name="search"),
	path('signup/', views.signup, name="signup"),
	path('handleLogin/', views.handleLogin, name="handleLogin"),
	path('logout/', views.handleLogout, name="handleLogout"),
	#path('products/', ProductList.as_view()),
	path('prodView/<str:nm>', views.prodView, name="prodView"),
	path('search/prodView/<str:nm>', views.prodView, name="prodView"),

]